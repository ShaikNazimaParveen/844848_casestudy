package com.example.registerlogincontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.registerlogin.service.RegisterLoginService;
import com.example.registerloginmodel.User;




@RestController
public class RegisterLoginController {
    
    @Autowired
    private RegisterLoginService service;
    
    @PostMapping("/register")
    public User registerUser(User user) throws Exception {
        String tempid = user.getEmailId();
        User userObj = null;
        if(tempid != null && !"".equals(tempid)) {
            userObj = service.fetchUserByEmailId(tempid);
            if(userObj != null) {
                throw new Exception("User with "+tempid+" is already exist");
            }
        }
        User userobj = null;
        userobj = service.saveUser(user);
        return userobj;
    }
    
    @PostMapping("/login")
    public User loginUser(User user) throws Exception {
        String tempid = user.getEmailId();
        String temppassword = user.getPassword();
        User userObj = null;
        if(tempid != null && temppassword != null) {
            userObj = service.fetchUserByEmailIdandPassword(tempid, temppassword);
        }
        if(userObj == null) {
            throw new Exception("User does not exist");
        }
        return userObj;
    }
}
 

