package com.example.registerlogin.repository;




import org.springframework.data.jpa.repository.JpaRepository;

import com.example.registerloginmodel.User;


public interface RegisterLoginRepository extends JpaRepository<User, Integer> {


public User fingByEmailId(String emailId);


public User findByEmailIdandPassword(String email, String password);


}