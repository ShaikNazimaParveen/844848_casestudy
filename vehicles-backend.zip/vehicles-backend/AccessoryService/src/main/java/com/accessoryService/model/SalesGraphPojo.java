package com.accessoryService.model;

import java.util.List;

public class SalesGraphPojo {
	
	private String model;
	private String region;
	private List<Axis> series;
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public List<Axis> getSeries() {
		return series;
	}
	public void setSeries(List<Axis> series) {
		this.series = series;
	}
	public SalesGraphPojo(String model, String region, List<Axis> series) {
		super();
		this.model = model;
		this.region = region;
		this.series = series;
	}
	
	

}