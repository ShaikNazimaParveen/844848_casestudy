package com.accessoryService.DAO;

import java.util.List;

import org.springframework.stereotype.Component;

import com.accessoryService.model.Accessory;

@Component
public interface AccessoryDAO {
	
	public List<Accessory> findBySalesId(int id);
	public List<Accessory> fingByAccessoryType(String type);

}
