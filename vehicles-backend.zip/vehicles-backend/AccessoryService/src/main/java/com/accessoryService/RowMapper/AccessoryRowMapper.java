package com.accessoryService.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.accessoryService.model.Accessory;

public class AccessoryRowMapper implements RowMapper<Accessory> {

	@Override
	public Accessory mapRow(ResultSet rs, int rowNum) throws SQLException {
		Accessory acc=new Accessory(rs.getString(1),rs.getDouble(2));
		return acc;
	}

}
