package com.accessoryService.DAOImpl;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.springframework.context.annotation.Configuration;

@Configuration
public class DateFormatter {
	
	public java.sql.Date dateConverter(String strdate) throws ParseException{
		SimpleDateFormat smf=new SimpleDateFormat("yyyy-MM-dd");
		java.util.Date date=smf.parse(strdate);
		return new java.sql.Date(date.getTime());
	}

}
