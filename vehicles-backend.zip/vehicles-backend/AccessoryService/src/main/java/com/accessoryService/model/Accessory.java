package com.accessoryService.model;

public class Accessory {
	
	private String accessoryType;
	private double accessoryCost;
	public String getAccessoryType() {
		return accessoryType;
	}
	public void setAccessoryType(String accessoryType) {
		this.accessoryType = accessoryType;
	}
	public double getAccessoryCost() {
		return accessoryCost;
	}
	public void setAccessoryCost(double accessoryCost) {
		this.accessoryCost = accessoryCost;
	}
	public Accessory(String accessoryType, double accessoryCost) {
		super();
		this.accessoryType = accessoryType;
		this.accessoryCost = accessoryCost;
	}
	@Override
	public String toString() {
		return "Accessory [accessoryType=" + accessoryType + ", accessoryCost=" + accessoryCost + "]";
	}

}
