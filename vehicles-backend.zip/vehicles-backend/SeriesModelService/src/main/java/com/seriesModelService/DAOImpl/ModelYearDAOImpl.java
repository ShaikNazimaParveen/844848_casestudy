package com.seriesModelService.DAOImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.seriesModelService.DAO.ModelYearDAO;
import com.seriesModelService.rowMapper.ModelYearRowMapper;

@Repository
public class ModelYearDAOImpl implements ModelYearDAO{
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<String> findByModelCodeAndSeries(String modelCode, String series) {
		String sql="select modelyear.model_year from \r\n" + 
				"model inner join series on model.id=series.model_id inner join modelyear\r\n" + 
				"on series.id=modelyear.series_id where model.model_code=? and series_name=?";
		List<String> str=jdbcTemplate.query(sql, new ModelYearRowMapper(), modelCode,series);
		return str ;
	}

}
