package com.seriesModelService.DAOImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.seriesModelService.DAO.AccessoryDAO;
import com.seriesModelService.rowMapper.AccessoryRowMapper;

@Repository
public class AccessoryDAOImpl implements AccessoryDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<String> findByModelCode(String modelCode) {
		String sql="select accessory.type from \r\n" + 
				"model inner join accessory on model.id=accessory.model_id\r\n" + 
				" where model.model_code=?";
		List<String> str=jdbcTemplate.query(sql,new AccessoryRowMapper(),modelCode);
		return str;
	}

}
