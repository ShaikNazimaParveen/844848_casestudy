package com.seriesModelService.DAOImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.seriesModelService.DAO.SeriesDAO;
import com.seriesModelService.rowMapper.SeriesRowMapper;

@Repository
public class SeriesDAOImpl implements SeriesDAO {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<String> findByModelCode(String modelCode) {
		String sql="select model.series_name from \r\n" + 
				"model inner join series on model.id=series.model_id\r\n" + 
				" where model.model_code=?";
		List<String> str=jdbcTemplate.query(sql, new SeriesRowMapper(), modelCode);
		return str ;
	}

}
