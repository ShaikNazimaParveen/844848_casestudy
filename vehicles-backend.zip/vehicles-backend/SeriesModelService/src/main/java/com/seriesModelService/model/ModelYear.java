package com.seriesModelService.model;

public class ModelYear {
	
	private String modelCode;
	private String seriesName;
	private String modelYear;
	public String getModelCode() {
		return modelCode;
	}
	public void setModelCode(String modelCode) {
		this.modelCode = modelCode;
	}
	public String getSeriesName() {
		return seriesName;
	}
	public void setSeriesName(String seriesName) {
		this.seriesName = seriesName;
	}
	public String getModelYear() {
		return modelYear;
	}
	public void setModelYear(String modelYear) {
		this.modelYear = modelYear;
	}
	public ModelYear(String modelCode, String seriesName, String modelYear) {
		super();
		this.modelCode = modelCode;
		this.seriesName = seriesName;
		this.modelYear = modelYear;
	}

}
