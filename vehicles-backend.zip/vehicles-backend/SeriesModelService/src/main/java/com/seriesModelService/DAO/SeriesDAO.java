package com.seriesModelService.DAO;

import java.util.List;

import org.springframework.context.annotation.Configuration;

@Configuration
public interface SeriesDAO {

	public List<String> findByModelCode(String modelCode);
}
